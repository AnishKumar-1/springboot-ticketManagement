INSERT INTO `Role`(role)VALUES
('ROLE_admin'),('ROLE_user'),('ROLE_support agent');


INSERT INTO `Users` 
(username,password, user_Role, created_At, updated_At) VALUES 
('user1', '$2a$12$mlgt6WKdQyeSfaa5gWO57.zLrsdv1Zin3tmlNM49dAzqSosckooiS', 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('user2', '$2a$12$nLso17huGi9X8Lu5IaH3l.ZSMvZP0NpHA.HwAKWWS/t8by./J9x5S', 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('user3', '$2a$12$ZrwzzInishC3OfwEmgs6z.Z1E8jibHxGVz2H8kkiZvmg07siHII3W', 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('user4', '$2a$12$AlaxMDOlqZHkv70t78/EQ.1BmD8YRnacxQSK.b5bgg7v5m3LZCLS.', 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('agent', '$2a$12$bLsa8maoOlJunt/PL6mhHu3HKS1Ah4SLVN/nDWeFqIqKzL.KBOOqy', 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('admin', '$2a$12$LJwekXJEzTJUm9smMXfnB.22cfOaiJ9LBTBSPpenMkNU18/qlTBcy', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
