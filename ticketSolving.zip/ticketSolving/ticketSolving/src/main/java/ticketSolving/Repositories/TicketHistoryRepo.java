package ticketSolving.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ticketSolving.Models.TicketHistory;

public interface TicketHistoryRepo extends JpaRepository<TicketHistory, Long>{

}
