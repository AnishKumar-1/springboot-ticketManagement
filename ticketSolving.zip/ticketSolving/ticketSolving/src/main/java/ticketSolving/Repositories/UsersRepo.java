package ticketSolving.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ticketSolving.Models.Users;

public interface UsersRepo extends JpaRepository<Users, Long>{
	public Users findByUsername(String username);

}
