package ticketSolving.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ticketSolving.Models.Role;

public interface RoleRepo extends JpaRepository<Role, Long>{

}
