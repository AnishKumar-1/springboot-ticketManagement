package ticketSolving.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ticketSolving.Models.Comment;

public interface CommentRepo extends JpaRepository<Comment,Long>{

}
