package ticketSolving.JWTHandler;

import java.security.Key;
import java.util.Date;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtHelper {

	//access key and decode it
	//we need expiration time and refreshexpiration time
	
	@Value("${privateKey}")
	private String accessKey;
	@Value("${tokenExpirationTime}")
	private long expirationTime;
	@Value("${refreshTokenExpirationTime}")
	private long refreshExpirationTime;
	
	//decode the key
	public Key getKey() {
		return Keys.hmacShaKeyFor(Decoders.BASE64.decode(accessKey));
	}
	
	//generate token
	//for this we need username and expiration time
	public String generateToken(Authentication authentication,long expiration) {
		String username=authentication.getName();
		String token=Jwts.builder()
				.header().empty().add("typ","JWT")
				.and().subject(username).issuedAt(new Date(System.currentTimeMillis()))
				.expiration(new Date(System.currentTimeMillis() + expiration))
				.signWith(getKey())
				.compact();
		
	     return token;
	}
	
	//valid for 3 hours
	public String generateAccessToken(Authentication auth) {
		return generateToken(auth,expirationTime);
	}
	
	//generate refresh token,valid for 7 days
	public String generateRefreshToken(Authentication auth) {
	   return generateToken(auth,refreshExpirationTime);
	}
	
	//extract claims from the token
	public <T> T extractAllClaims(String token,Function<Claims, T> claimResolver) {
		Claims claim=Jwts.parser().verifyWith((SecretKey) getKey()).build()
				.parseSignedClaims(token).getPayload();
		return claimResolver.apply(claim);
		
	}
	//extract username from the token,require when we validate the token
	public String extractUseranme(String token) {
		return extractAllClaims(token,Claims::getSubject);
	}
	//create method to check if token doesn't expired
	public boolean isTokenExpired(String token) {
		return extractAllClaims(token,Claims::getExpiration).before(new Date());
	}
	
	//validate token
	public boolean isTokenValid(String token) {
		try {
			Jwts.parser().verifyWith((SecretKey) getKey()).build().parse(token);
			return true;
		}catch(ExpiredJwtException ex) {
			throw new ExpiredJwtException(null, null, "token has expired");
		}catch(MalformedJwtException ex) {
			throw new MalformedJwtException("invalid token");
		}catch(Exception ex) {
			throw new RuntimeException("something went wrong");
		}
	}
}
