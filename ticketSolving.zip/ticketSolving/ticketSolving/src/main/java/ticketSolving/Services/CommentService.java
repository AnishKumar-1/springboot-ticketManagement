package ticketSolving.Services;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import ticketSolving.DTO.CommentDto;
import ticketSolving.DTO.UserDto;
import ticketSolving.ErrorHandling.CustomResouceNotFound;
import ticketSolving.Models.Comment;
import ticketSolving.Models.Role;
import ticketSolving.Models.Ticket;
import ticketSolving.Models.Users;
import ticketSolving.Repositories.CommentRepo;
import ticketSolving.Repositories.TicketRepo;
import ticketSolving.Repositories.UsersRepo;
import java.util.*;



@Service
public class CommentService {

    @Autowired
    private TicketRepo ticketRepo;
    
    @Autowired
    private UsersRepo userRepo;
    
    @Autowired
    private CommentRepo commentRepo;
    
    private Users getAuthenticatedUser() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepo.findByUsername(username);
    }
    
    public CommentDto createComment(Long ticketId, CommentDto commentDto) {
        Optional<Ticket> ticketOpt = ticketRepo.findById(ticketId);
        if (!ticketOpt.isPresent()) {
            throw new CustomResouceNotFound("Ticket doesn't exist with id: " + ticketId);
        }

        Ticket ticket = ticketOpt.get();
        Users currentUser = getAuthenticatedUser();
        Role currentRole = currentUser.getRole();
        
        boolean isAdminOrAgent = currentRole.getRole().equals("ROLE_admin") || currentRole.getRole().equals("ROLE_support agent");
        boolean isTicketOwner = ticket.getUser().getUserId() == currentUser.getUserId();

        if (!isAdminOrAgent && !isTicketOwner) {
            throw new RuntimeException("unauthorized");
        }

        Comment comment = new Comment();
        comment.setComment(commentDto.getComment());
        comment.setCretedAt(LocalDateTime.now());
        comment.setUser(currentUser);
        comment.setTicket(ticket);

        Comment savedComment = commentRepo.save(comment);
        return commentToCommentDto(savedComment);
    }
    
    
    //get all comment for any ticket id admin,agent,ticket owner
    public List<CommentDto> getAllComment(Long ticketId){
    	if(ticketId==null) {
    		throw new RuntimeException("ticket id not found");
    	}
    	Optional<Ticket> ticket=ticketRepo.findById(ticketId);
    	if(!ticket.isPresent()) {
            throw new CustomResouceNotFound("record not found with this id: " + ticketId);
    	}
    	Role role=getAuthenticatedUser().getRole();
    	boolean isAdminOrAgent=role.getRole().equals("ROLE_admin") || role.getRole().equals("ROLE_support agent");
    	boolean isOwner=ticket.get().getUser().getUserId()==getAuthenticatedUser().getUserId();
    	if(!isAdminOrAgent && !isOwner) {
            throw new RuntimeException("unauthorized");
    	}
    	return ticket.get().getComments().stream().map(x->commentToCommentDto(x)).collect(Collectors.toList());
    }
    
    //update comment for a specific ticket,only comment owner
    public CommentDto commentUpdate(Long ticketId,Long commentId,CommentDto comment) {
    	if(ticketId==null) {
    		throw new RuntimeException("ticket id not found");
    	}
    	if(commentId==null) {
    		throw new RuntimeException("comment id not found");
    	}
    	Optional<Ticket> ticket=ticketRepo.findById(ticketId);
    	if(!ticket.isPresent()) {
    		throw new CustomResouceNotFound("record not found");
    	}
    	Optional<Comment> storedComment=commentRepo.findById(commentId);
    	if(!storedComment.isPresent()) {
    		throw new CustomResouceNotFound("comment doesn't exist with id: "+commentId);
    	}
    	boolean isCommentOwner=storedComment.get().getUser().getUserId()==getAuthenticatedUser().getUserId();
    	if(!isCommentOwner) {
    		throw new AccessDeniedException("unauthorized");
    	}
    	if(comment==null) {
    		commentRepo.save(storedComment.get());
    	}
    	storedComment.get().setComment(comment.getComment());
    	storedComment.get().setUpdatedAt(LocalDateTime.now());
    	Comment updatedComment = commentRepo.save(storedComment.get());
    	return commentToCommentDto(updatedComment);
    }
    
    //delete comment of a ticket by comment id 
    public String deleteComment(Long ticketId,Long commentId) {
    	if(ticketId==null) {
    		throw new RuntimeException("ticket id not found");
    	}
    	if(commentId==null) {
    		throw new RuntimeException("comment id not found");
    	}
    	if(!ticketRepo.existsById(ticketId)) {
    		throw new CustomResouceNotFound("record not found");
    	}
    	if(!commentRepo.existsById(commentId)) {
    		throw new CustomResouceNotFound("comment doesn't exist with id: "+commentId);
    	}
    	Optional<Comment>storedComment=commentRepo.findById(commentId);
    	boolean isCommentOwner=storedComment.get().getUser().getUserId()==getAuthenticatedUser().getUserId();
    	boolean isAdminOrAgent=getAuthenticatedUser().getRole().getRole().equals("ROLE_admin");
    	if(!isCommentOwner && !isAdminOrAgent) {
    		throw new AccessDeniedException("unauthorized");
    	}
    	commentRepo.deleteById(commentId);
    	return "comment deleted successfully.";
    	
    }
    
    // common method commentToCommentDto
    public CommentDto commentToCommentDto(Comment comment) {
        CommentDto commentDto = new CommentDto();
        commentDto.setComment(comment.getComment());
        commentDto.setCommentId(comment.getCommentId());
        commentDto.setCretedAt(comment.getCretedAt());
        commentDto.setUpdatedAt(comment.getUpdatedAt());
        commentDto.setUserDto(new UserDto(comment.getUser().getUserId(), comment.getUser().getUsername()));
        return commentDto;  // corrected return statement
    }
}