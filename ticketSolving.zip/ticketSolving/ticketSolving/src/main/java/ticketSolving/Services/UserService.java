package ticketSolving.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import ticketSolving.DTO.JwtResponse;
import ticketSolving.DTO.LoginDto;
import ticketSolving.JWTHandler.JwtHelper;
import ticketSolving.SecurityConfig.CustomUserDetails;

@Service
public class UserService {

	@Autowired
	CustomUserDetails customUserDetails;
	
	@Autowired
	private JwtHelper jwtHelper;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	public JwtResponse login(LoginDto user) {
		try {
		Authentication authentication=authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String accessToken=jwtHelper.generateAccessToken(authentication);
		String refreshToken=jwtHelper.generateRefreshToken(authentication);
		return new JwtResponse(accessToken,refreshToken);
		}catch(Exception ex) {
			throw new UsernameNotFoundException("unauthorized");
		}
	}
	
	//for refresh token
	public String getRefreshToken(String token) {
		if(!jwtHelper.isTokenValid(token)) {
		   throw new IllegalArgumentException("invalid or expired refresh token");
 		}
		String username=jwtHelper.extractUseranme(token);
		UserDetails userDetails=customUserDetails.loadUserByUsername(username);
		Authentication authentication=new UsernamePasswordAuthenticationToken(userDetails, null,userDetails.getAuthorities());
		SecurityContextHolder.getContext().setAuthentication(authentication);
		return jwtHelper.generateAccessToken(authentication);
	}
}
