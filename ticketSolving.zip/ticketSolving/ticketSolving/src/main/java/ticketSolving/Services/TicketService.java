package ticketSolving.Services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import ticketSolving.DTO.CommentDto;
import ticketSolving.DTO.TicketDto;
import ticketSolving.DTO.UserDto;
import ticketSolving.ErrorHandling.CustomResouceNotFound;
import ticketSolving.Models.Comment;
import ticketSolving.Models.Ticket;
import ticketSolving.Models.Users;
import ticketSolving.Repositories.TicketRepo;
import ticketSolving.Repositories.UsersRepo;

@Service
public class TicketService {
	
	@Autowired
	private UsersRepo userRepo;
	@Autowired
	private TicketRepo ticketRepo;
	
	
	public Users getAuthenticatedUser() {
		String username=SecurityContextHolder.getContext().getAuthentication().getName();
		return userRepo.findByUsername(username);
	}
	
	//create ticket
	public TicketDto createTicket(TicketDto ticketDto) {
		Ticket ticket=new Ticket();
		ticket.setCreatedAt(LocalDateTime.now());
		ticket.setDescription(ticketDto.getDescription());
		ticket.setPriority(ticketDto.getPriority());
		ticket.setPriority("low");
	    ticket.setStatus(ticketDto.getStatus()==null?"open":ticketDto.getStatus());
		ticket.setTitle(ticketDto.getTitle());
		Users user=getAuthenticatedUser();
		ticket.setUser(user);
		return convertToTicketResponseDto(ticketRepo.save(ticket));
			
	}
	
	//get all users
	public List<TicketDto> getAllTickets(){
		List<Ticket>tickets=ticketRepo.findAll();
		List<TicketDto> result=new ArrayList<>();
		for(Ticket ticket:tickets) {
			result.add(convertToTicketResponseDto(ticket));
		}
		return result;
	}
	
	//get ticket by id
	public TicketDto ticketById(Long ticketId) {
		if(ticketId==null) {
			throw new IllegalArgumentException("Ticket ID cannot be null.");
		}
		Optional<Ticket> optional=ticketRepo.findById(ticketId);
		if(optional.isEmpty()) {
			throw new CustomResouceNotFound("user not found with id: "+ticketId);
		}
		Users currentLogedInUser=getAuthenticatedUser();
		Ticket ticket=optional.get();
		boolean isAdminOrSupportAgent = currentLogedInUser.getRole().getRole().equals("ROLE_admin") || 
				currentLogedInUser.getRole().getRole().equals("ROLE_support agent");
        boolean isTicketOwner = (ticket.getUser().getUserId())==(currentLogedInUser.getUserId());
		
		if(!isAdminOrSupportAgent && !isTicketOwner) {
			throw new RuntimeException("you don't have permission to see this ticket");
		}
		return convertToTicketResponseDto(ticket);	
	}
	
	//update ticket
	public TicketDto updateTicket(Long ticketId,TicketDto ticketDto) {
		Optional<Ticket> userTicket=ticketRepo.findById(ticketId);
		if(!userTicket.isPresent()) {
			throw new CustomResouceNotFound("Ticket with ID: " + ticketId + " does not exist.");
		}
		Ticket ticket = userTicket.get();
		if(!ticketDto.getStatus().isEmpty()) {
			ticket.setStatus(ticketDto.getStatus());
			ticket.setUpdatedAt(LocalDateTime.now());
		}
		
		return convertToTicketResponseDto(ticketRepo.save(ticket));
	}
	
	//delet ticket by id
	public String deleteTicket(Long ticketId) {
		if(!ticketRepo.existsById(ticketId)) {
			throw new CustomResouceNotFound("Ticket with ID: " + ticketId + " does not exist.");
		}
		ticketRepo.deleteById(ticketId);
		return "ticket deleted successfully.";
	}
	
    // Convert ticket object to TicketReponseDto
	public TicketDto convertToTicketResponseDto(Ticket ticket) {
		TicketDto ticketDto=new TicketDto();
		ticketDto.setCreated_at(ticket.getCreatedAt());
		ticketDto.setDescription(ticket.getDescription());
		ticketDto.setPriority(ticket.getPriority());
		ticketDto.setStatus(ticket.getStatus());
		ticketDto.setTicketId(ticket.getTicketId());
		ticketDto.setTitle(ticket.getTitle());
		UserDto userDto=new UserDto(ticket.getUser().getUserId(),ticket.getUser().getUsername());
		ticketDto.setUserDto(userDto);
		if(ticket.getComments() !=null) {
		List<CommentDto> commentList=new ArrayList<>();
		for(Comment comment:ticket.getComments()) {
			CommentDto dto=new CommentDto();
			dto.setComment(comment.getComment());
			dto.setCommentId(comment.getCommentId());
			dto.setCretedAt(comment.getCretedAt());
			dto.setUpdatedAt(comment.getUpdatedAt());
			dto.setUserDto(new UserDto(comment.getUser().getUserId(),comment.getUser().getUsername()));
			commentList.add(dto);
		}
		ticketDto.setComments(commentList);
		}
		return ticketDto;
	}
}
