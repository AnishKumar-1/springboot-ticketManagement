package ticketSolving.SecurityConfig;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import ticketSolving.Models.Users;
import ticketSolving.Repositories.UsersRepo;
@Component
public class CustomUserDetails implements UserDetailsService{

	@Autowired
	private UsersRepo userRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
	     Users user=userRepo.findByUsername(username);
	     SimpleGrantedAuthority authority=new SimpleGrantedAuthority(user.getRole().getRole());
		return new User(user.getUsername(),user.getPassword(),Collections.singleton(authority));
	}

}
