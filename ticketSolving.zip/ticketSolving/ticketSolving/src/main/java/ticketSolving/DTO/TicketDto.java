package ticketSolving.DTO;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TicketDto {
	    private long ticketId;
	    @NotEmpty(message = "Title cannot be empty")
	    private String title;
	    @NotEmpty(message = "Description should have at least 10 characters")
	    private String description;
	    private String priority;
	    private String status;
	    private LocalDateTime created_at;
	    @JsonInclude(JsonInclude.Include.NON_NULL)
		private LocalDate update_at;
		private UserDto userDto;
		@JsonInclude(JsonInclude.Include.NON_NULL)
	    private List<CommentDto> comments;
	    
}
