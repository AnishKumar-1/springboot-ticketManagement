package ticketSolving.DTO;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CommentDto {
	private long commentId;
	@NotEmpty(message="comment connot be empty")
	private String comment;
	private LocalDateTime cretedAt;
	private UserDto userDto;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private LocalDateTime updatedAt;
}
