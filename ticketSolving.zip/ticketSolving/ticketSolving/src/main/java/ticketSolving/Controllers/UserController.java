package ticketSolving.Controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import ticketSolving.DTO.JwtResponse;
import ticketSolving.DTO.LoginDto;

import ticketSolving.Services.UserService;

@RestController
@RequestMapping("${baseUrl}")
public class UserController {

	@Autowired
	private UserService userService;
	

	
	@PostMapping("/login")
	public ResponseEntity<JwtResponse> userLogin(@RequestBody LoginDto loginDto){
		return new ResponseEntity<>(userService.login(loginDto),HttpStatus.OK);
	}
	
	//to get refresh token
	@PostMapping("/refresh")
	public ResponseEntity<String> getRefreshToken(HttpServletRequest request) {
		String token=request.getHeader("Authorization");
		if(token==null || !token.startsWith("Bearer")) {
			throw new IllegalArgumentException("token not found or invalid");
		}
		try {
			String oldToken=token.substring(7);
			String newToken=userService.getRefreshToken(oldToken);
            return new ResponseEntity<>(newToken, HttpStatus.OK);
		}catch(IllegalArgumentException ex) {
            return new ResponseEntity<>("Invalid token", HttpStatus.BAD_REQUEST);
		}catch(Exception ex) {
			 return new ResponseEntity<>("An error occured", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

}
