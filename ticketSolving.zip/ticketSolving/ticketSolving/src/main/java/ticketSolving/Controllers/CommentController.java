package ticketSolving.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import ticketSolving.DTO.CommentDto;
import ticketSolving.Services.CommentService;

@RestController
@RequestMapping("${baseUrl}")
public class CommentController {

	@Autowired
	private CommentService commentSerive;
	
	@PostMapping("/ticket/{ticketId}/comment")
	public ResponseEntity<CommentDto> createComment(@PathVariable Long ticketId, @Valid @RequestBody CommentDto dto) {
	    return new ResponseEntity<>(commentSerive.createComment(ticketId, dto), HttpStatus.CREATED);
	}
	
	
	//getAllcomment of a ticket by its id
	//can get all comments only admin,agent and comment Owner
	@GetMapping("/ticket/{ticketId}/comment")
	public List<CommentDto> getAllComment(@PathVariable Long ticketId){
		return commentSerive.getAllComment(ticketId);
	}
	
	//update comment of ticket by its id and commentid
	//only comment Owner can update it
	@PutMapping("/ticket/{ticketId}/comment/{commentId}")
	public ResponseEntity<CommentDto> updateComment(@PathVariable Long ticketId,@PathVariable Long commentId,@RequestBody CommentDto comment){
		return ResponseEntity.ok(commentSerive.commentUpdate(ticketId, commentId, comment));
	}
	
	//delete comment of a ticket by its id
	//only admin and the commentOwner can delete it
	@DeleteMapping("/ticket/{ticketId}/comment/{commentId}")
	public ResponseEntity<String> deleteComment(@PathVariable Long ticketId,@PathVariable Long commentId){
		return ResponseEntity.ok(commentSerive.deleteComment(ticketId, commentId));
	}
}
