package ticketSolving.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import ticketSolving.DTO.TicketDto;
import ticketSolving.Services.TicketService;

@RestController
@RequestMapping("${baseUrl}")
public class TicketController {

	@Autowired
	private TicketService ticketService;
	
	@PostMapping("/ticket")
	public ResponseEntity<TicketDto> createTicket(@Valid @RequestBody TicketDto dto){
		return new ResponseEntity<>(ticketService.createTicket(dto),HttpStatus.CREATED);
	}
	
	@GetMapping("/ticket")
	@PreAuthorize("hasRole('admin') or hasRole('support agent')")
	public ResponseEntity<List<TicketDto>> getAllTickets(){
		return ResponseEntity.ok(ticketService.getAllTickets());
	}
	
	//get ticket by id
	@GetMapping("/ticket/{ticketId}")
	public ResponseEntity<TicketDto> ticketById(@PathVariable Long ticketId){
		return ResponseEntity.ok(ticketService.ticketById(ticketId));
	}
	
	//put mapping
	@PutMapping("/ticket/{ticketId}")
	@PreAuthorize("hasRole('admin') or hasRole('support agent')")
	public ResponseEntity<TicketDto> updateTicket(@PathVariable Long ticketId,@RequestBody TicketDto dto){
		return ResponseEntity.ok(ticketService.updateTicket(ticketId,dto));
	}
	
	//delete ticket
	@DeleteMapping("/ticket/{ticketId}")
	@PreAuthorize("hasRole('admin')")
	public ResponseEntity<String> updateTicket(@PathVariable Long ticketId){
		return ResponseEntity.ok(ticketService.deleteTicket(ticketId));
	}
}
