package ticketSolving.ErrorHandling;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.HashMap;

@RestControllerAdvice
public class GlobalErrorHandling {
  private final SimpleDateFormat dateformate=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  
  @ExceptionHandler(Exception.class)
  public ResponseEntity<CustomError> handleError(Exception ex,HttpServletRequest request){
	  CustomError customError=new CustomError();
	  customError.setError(ex.getLocalizedMessage());
	  customError.setPath(request.getRequestURI());
	  customError.setTimestamp(dateformate.format(new Date()));
	  

      if (ex instanceof RuntimeException || ex instanceof IllegalArgumentException || ex instanceof ExpiredJwtException) {
          customError.setError(ex.getLocalizedMessage());
          customError.setStatus(HttpStatus.BAD_REQUEST);
      } else if (ex instanceof AuthorizationDeniedException) {
          customError.setStatus(HttpStatus.FORBIDDEN);
      } else if (ex instanceof ClassCastException) {
          customError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
      } else if (ex instanceof HttpMessageNotReadableException) {
          customError.setError("Invalid JSON");
          customError.setStatus(HttpStatus.BAD_REQUEST);
      } else if (ex instanceof AccessDeniedException) {
          customError.setStatus(HttpStatus.UNAUTHORIZED);
      } else {
          // Default status if no specific exception type matches
          customError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
      }

      return new ResponseEntity<>(customError, customError.getStatus());
  }
  
  
  //for the field validation
  @ExceptionHandler(MethodArgumentNotValidException.class)
  public ResponseEntity<Map<String,String>> methodLevelErrorHandler(MethodArgumentNotValidException ex){
	  Map<String,String>errors=new HashMap<>();
	  ex.getBindingResult().getFieldErrors().stream().forEach(x->errors.put(x.getField(), x.getDefaultMessage()));
	  return new ResponseEntity<>(errors,HttpStatus.BAD_REQUEST);
	  
  }
}
