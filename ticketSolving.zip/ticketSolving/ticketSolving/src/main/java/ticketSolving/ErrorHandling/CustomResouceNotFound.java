package ticketSolving.ErrorHandling;

public class CustomResouceNotFound extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CustomResouceNotFound(String message) {
		super(message);
	}

}
